function program3(I, J)
% Funkcija PROGRAM3 na območju I x J naključno izbira točke. Dve zaporedoma
% izbrani točki poveže z daljico. Tako nariše poligonsko črto. Program se
% konča, če poligonska črta seka samo sebe. Tedaj izračuna ogljišča
% poligona, ki ni nujno preprosti mnogokotnik. Vrne sliko in ploščino lika.

% Določimo območje, na katerem lahko program izbira točke
%I = [0, 10];
%J = [0, 10];

% števec za število premic, ki smo jih narisali
n = 1;
se_sekata = false;

% pripravimo array, kamor bomo shranjevali točke poligona, ki ga
% generiramo
tocke = zeros(2, 1);

% dodajmo prvo točko
[prva_tocka_x, prva_tocka_y] = rand_tocke(I, J);
tocke(:, n) = [prva_tocka_x; prva_tocka_y];
hold on;

while se_sekata == false
    n = n + 1;

    % dodajmo naslednjo točko 
    [tocka_x, tocka_y] = rand_tocke(I, J);
    tocke(:, n) = [tocka_x; tocka_y];

    % narišimo daljico, ki povezuje novo dodano točko s prejšnjo
    daljica(tocke(:, n-1), tocke(:, n)); % = tocke_na_daljici
    hold on;
    pause(0.2);

    % preverimo, ali nova daljica seka katero od prejšnjih daljic, razen
    % ene pred njo, t. j. (n-1)-ve
    for i = 2:n-2
        % zadnja dodana daljica povezuje točki
        p_n = tocke(:, n-1:n);
        % i-ta dodana daljica povezuje točki
        p_i = tocke(:, i-1:i);

        se_sekata = preveri_presecisce_orientacija(p_n, p_i);

        % če smo našli presečišče izračunamo vsa presečišča z zadnjo dodano
        % premico p_n
        if se_sekata == true

            % Tabela vseh presečišč p_n z ostalimi premicami vključno s
            % parametrom t, pri katerem ima p_n(t) presečišče, in s
            % številko premice p_j, ki p_n seka
            presecisca = zeros(4, 0);

            % presečišča moramo preveriti zgolj s premicami p_1...p_i, saj
            % vemo, da s premicami p_i+1 ... p_n-2 p_n nima skupne točke
            l = 0;
            for j = 2:n-2
                p_j = tocke(:, j-1:j);

                % v tabelo presečišča shranimo vse najdene točke, ki
                % ustrezajo pogoju
                if preveri_presecisce_orientacija(p_n, p_j) == true
                    l = l + 1;
                    [presek_t, presek] = presecisce_daljic(p_n, p_j);
                    presecisca(:, l) = [j-1; presek_t(1); presek(1); presek(2)];
                    k = j-1;
                end
            end

            % sedaj ločimo dve možnosti: obstaja eno presečišče in obstaja
            % več presečišč

            % Uredimo jih po naraščajočem t
            presecisca = sortrows(presecisca.', 2).';
            plot(presecisca(3,:), presecisca(4,:), "x", 'Color', "b");

            % označujmo premice, ki jih p_n seka s q_1 ... q_k, kjer p_n
            % najprej seka q_1, nato q_2 ...

            % če je presečišče samo eno, vemo, da so ogljišča naslednja
            % tudi če je q_1 enak zadnji narisani premici p_1 izmed q_1
            % ... q_k, poznamo ogljišča lika
            if length(presecisca(1, :)) == 1 
                lik = [tocke(:, k+1:n-1), presecisca(3:4, 1)];
                break;
            end

            % Če je presečišč več, preverimo, če je bila prva, ki jo p_n
            % seka narisana pred ali za zadnjo, saj potem dodajamo točke v
            % obratnem vrstnem redu.
            len = length(presecisca(1,:));
            ploscina = 0;
            if presecisca(1,1) < presecisca(1, len)

                % Med ogljišča dodajmo prvo najdeno presečišče
                lik = [presecisca(3:4,1)];
                s = presecisca(1,1);

                % Za vsak par zaporednih presečišč z daljicama p_s in p_t
                % dodamo točke (x_s+1, y_s+1) ... (t_t, y_t)
                for j = 2:len
                    t = presecisca(1, j);
                    
                    % Če je bila naslednje p_t dodana kasneje kot p_s,
                    % dodamo točke 
                    if t > s 
                        lik = [lik tocke(:, s+1:t) presecisca(3:4, j)];

                        pomozen = [lik(:, length(lik(1,:))) tocke(:, s+1:t) presecisca(3:4, j)];
                        ploscina = ploscina + polyarea(pomozen(1,:), pomozen(2,:));

                    end
                    s = t;
                end

            else

                % Tudi v drugem primeru najprej dodajmo prvo presečišče
                lik = [presecisca(3:4,1)];
                s = presecisca(1,1);
                for j = 2:len

                    % Za vsak par zaporednih presečišč z daljicama p_s in p_t
                    % dodamo točke (x_s, y_s) ... (x_t+1, y_t+1), torej v
                    % obratnem vrstnem redu kot prej
                    t = presecisca(1, j);
                    if t < s 
                        lik = [lik tocke(:, s:-1:t+1) presecisca(3:4, j)];

                        pomozen = [lik(:, length(lik(1,:))) tocke(:, s:-1:t+1) presecisca(3:4, j)];
                        ploscina = ploscina + polyarea(pomozen(1,:), pomozen(2,:));

                    end
                    s = t;
                end

            end

            % Na koncu dodamo še točke od zadnjega presečišča do zadnje
            % dodane točke oz. od prvega presečišča do zadnje dodane
            % točke, če je bila daljica, ki jo p_n seka najprej
            % narisana prva 
            % t = max(presecisca(1, :));
                 
            if presecisca(1,1) ~= min(presecisca(1,:))
                lik = [lik tocke(:, n-1:-1:t+1) presecisca(3:4, 1)];

                pomozen = [lik(:, length(lik(1,:))) tocke(:, n-1:-1:t+1) presecisca(3:4, 1)];
                ploscina = ploscina + polyarea(pomozen(1,:), pomozen(2,:));

            elseif rem(len, 2) == 0 && presecisca(1,1) == 1
                lik = [lik tocke(:, t+1:n-1) presecisca(3:4, len)];

                pomozen = [lik(:, length(lik(1,:))) tocke(:, t+1:n-1) presecisca(3:4, len)];
                ploscina = ploscina + polyarea(pomozen(1,:), pomozen(2,:));

            end
            break;
         
        end
    end
end

% obarvajmo lik
siva = [0.7 0.7 0.7];
fill(lik(1,:), lik(2,:), siva);
alpha(0.5);  % spremenimo opaznost osenčenega lika

% izračunajmo še ploščino lika
%ploscina = polyarea(lik(1, :), lik(2,:));
fprintf("Ploščina obarvanega lika je %s. \n", ploscina);

hold off;